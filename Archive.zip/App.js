import React, { Component } from 'react';
import AppNavigate from './src/routes';

export default class App extends Component {
    render() {
        return (<AppNavigate />);
    }
}
