import React from 'react';
import { createStackNavigator, createDrawerNavigator } from 'react-navigation';
import HomeScreen from './containers/pages/HomeScreen';
import DetailsScreen from './containers/pages/DetailsScreen';
import DrawerScreen from './containers/pages/DrawerScreen';

const DetailsScreenNav = createStackNavigator({
    Detail: {
        screen: DetailsScreen,
        navigationOptions: () => ({
            title: 'Details page'
        })
    }
});

export default AppNavigate = createDrawerNavigator({
    Home: {
        screen: HomeScreen
    },
    Detail: {
        screen: DetailsScreenNav
    }
}, {
    contentComponent: props => <DrawerScreen {...props}/>
});