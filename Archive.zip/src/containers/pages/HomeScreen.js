import React, { Component } from 'react';
import { View, StyleSheet, Text, Button } from 'react-native';
import ScreenStyles from '../../assets/styles/app';

class HomeScreen extends Component {
    render() {
        return (
            <View  style={ScreenStyles.container}>
                <Text> This is home page.. </Text>
                <Button 
                title='Go to detail'
                onPress={() => this.props.navigation.navigate('Detail')}
                />
            </View>
        );
    }
}

export default HomeScreen;
