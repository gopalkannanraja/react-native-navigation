import React, { Component } from 'react';
import { View, StyleSheet, Text } from 'react-native';
import ScreenStyles from '../../assets/styles/app';

class DetailsScreen extends Component {
    // static navigationOptions = {
    //     title: 'Detail screen'
    // }
    render() {
        return (
            <View style={ScreenStyles.container}>
                <Text> This is details page.. </Text>
            </View>
        );
    }
}

export default DetailsScreen;

