import React, { Component } from 'react';
import { View, StyleSheet, Text, Button } from 'react-native';
import ScreenStyles from '../../assets/styles/app';

class DrawerScreen extends Component {
    render() {
        return (
            <View style={ScreenStyles.container}>
                <Text> DrawerScreen </Text>
            </View>
        );
    }
}

export default DrawerScreen;

